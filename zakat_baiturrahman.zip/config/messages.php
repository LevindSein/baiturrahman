<?php
return [
    'required' => ':attribute wajib diisi',
    'min' => ':attribute diisi minimal :min karakter',
    'max' => ':attribute diisi maksimal :max karakter',
    'alpha_dash' => ":attribute hanya dapat diisi huruf, angka, dash dan underscores",
]
?>
