<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="mobile-web-app-capable" content="yes">
        <meta name="viewport" content="minimal-ui, width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <meta name="keyword" content="Portal Masjid Baiturrahman, Pembayaran Zakat, Pemuda Baiturrahman, Masjid Baiturrahman, Taman Senopati, Villa Permata Cikampek"/>
        <meta name="author" content="Pemuda Baiturrahman - Levind Sein, Eki, Fahni"/>
        <meta name="description"content="Zakat, Infaq, Shodaqoh, lebih mudah bersama Masjid Baiturrahman" />
        <meta property="og:site_name" content="Berzakat di Masjid Baiturrahman">
        <meta property="og:title" content="Berzakat di Masjid Baiturrahman" />
        <meta property="og:description" content="Penghubung Muzzaki dan Mustahik" />
        <meta property="og:image" itemprop="image" content="<?php echo e(asset($Gsetting->favicon)); ?>">
        <meta property="og:url" content="https://www.anydemo.kapns.com/login/" />
        <meta property="og:type" content="website" />
        <link rel="shortcut icon" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="icon" sizes="16x16 32x32 64x64" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="icon" sizes="196x196" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="icon" sizes="160x160" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="icon" sizes="96x96" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="icon" sizes="64x64" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="icon" sizes="32x32" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="icon" sizes="16x16" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="apple-touch-icon" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset($Gsetting->favicon)); ?>">
        <meta name="google" content="notranslate">

        <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>

        
        <link rel="stylesheet" href="<?php echo e(asset('home/login/style.css')); ?>"/>

        

        <script src="<?php echo e(asset('home/login/jquery.min.js')); ?>"></script>

        
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/login/toastr.min.css')); ?>">
        <script src="<?php echo e(asset('home/login/toastr.min.js')); ?>"></script>

        <title> <?php echo e($Gsetting->title); ?></title>
    </head>
    <body>
        <div class="container">
            <div class="forms-container">
                <div class="signin-signup">
                    <form action="<?php echo e(url('login')); ?>" class="sign-in-form" method="post">
                        <?php echo csrf_field(); ?>
                        <h2 class="title">Login</h2>
                        <div class="input-field">
                            <i class="fas fa-user"></i>
                            <input required type="text" autocomplete="off" maxlength="50" name="username" placeholder="Username/Email/No.Hp" style="text-transform:lowercase;"/>
                        </div>
                        <div class="input-field">
                            <i class="fas fa-lock"></i>
                            <input required type="password" minlength="5" name="password" placeholder="Password"/>
                        </div>
                        <input type="submit" value="Masuk" class="btn solid"/>
                        <a href="#" class="social-text">Lupa password ?</a>
                        <div class="social-media">
                            <a href="<?php echo e($Gsetting->phone); ?>" target="_blank" class="social-icon">
                                <i class="fas fa-phone"></i>
                            </a>
                            <a href="<?php echo e($Gsetting->email); ?>" target="_blank" class="social-icon">
                                <i class="fas fa-envelope"></i>
                            </a>
                            <a href="<?php echo e($Gsetting->address); ?>" target="_blank" class="social-icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </a>
                        </div>
                    </form>
                    <form action="#" class="sign-up-form">
                        <h2 class="title">Registrasi</h2>
                        <div class="input-field">
                            <i class="fas fa-envelope"></i>
                            <input required type="text" autocomplete="off" maxlength="50" name="username" placeholder="Email/No.Hp" style="text-transform:lowercase;"/>
                        </div>
                        <div class="input-field">
                            <i class="fas fa-lock"></i>
                            <input required type="password" minlength="5" name="password" placeholder="Password"/>
                        </div>
                        <div class="input-field">
                            <i class="fas fa-lock"></i>
                            <input required type="password" minlength="5" name="password" placeholder="Konfirmasi Password"/>
                        </div>
                        <input type="submit" class="btn" value="Daftar"/>
                    </form>
                </div>
            </div>

            <div class="panels-container">
                <div class="panel left-panel">
                    <div class="content">
                        <h3><?php echo e($Gsetting->home_text->home_text_title_1); ?></h3>
                        <p><?php echo e($Gsetting->home_text->home_text_desc_1); ?></p>
                        <button class="btn transparent" id="sign-up-btn">
                            Daftar
                        </button>
                    </div>
                    <img src="<?php echo e(asset($Gsetting->home_img_1)); ?>" class="image" alt=""/>
                </div>
                <div class="panel right-panel">
                    <div class="content">
                        <h3><?php echo e($Gsetting->home_text->home_text_title_2); ?></h3>
                        <p><?php echo e($Gsetting->home_text->home_text_desc_2); ?></p>
                        <button class="btn transparent" id="sign-in-btn">
                            Masuk
                        </button>
                    </div>
                    <img src="<?php echo e(asset($Gsetting->home_img_2)); ?>" class="image" alt=""/>
                </div>
            </div>
        </div>

        <script src="<?php echo e(asset('home/login/app.js')); ?>"></script>
        <script src="<?php echo e(asset('custom.js')); ?>"></script>
        <script>
            var field = document.querySelector('[name="username"]');

            field.addEventListener('keypress', function ( event ) {
            var key = event.keyCode;
                if (key === 32) {
                event.preventDefault();
                }
            });
        </script>

        <?php echo $__env->make('message.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\gozakat\zakat_baiturrahman\resources\views/home/login.blade.php ENDPATH**/ ?>